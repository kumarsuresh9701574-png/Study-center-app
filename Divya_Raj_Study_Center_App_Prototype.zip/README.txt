Divya Raj Study Center - App Prototype

This is a functional mobile-friendly prototype.
Open index.html in a browser. It includes:
- Login screen
- Home dashboard
- Study Materials
- Online Test / Quiz
- Result
- Notice
- Profile

The buttons and navigation work locally. Real login, database, PDF/video uploads,
teacher/admin accounts, notifications, and publishing to Play Store require a backend
and production Android build.
